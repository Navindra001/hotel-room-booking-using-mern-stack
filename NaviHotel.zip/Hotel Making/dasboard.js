document.addEventListener('DOMContentLoaded', () => {
  const usernamePlaceholder = document.getElementById('username-placeholder');
  const table = document.querySelector('table');
  const updateDetailsButton = document.getElementById('update-details');
  const deleteAccountButton = document.getElementById('delete-account');
  const emailForm = document.getElementById('email-form');

  // Fetch user data when the form is submitted
  emailForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent the form from actually submitting

    const emailInput = document.getElementById('email');
    const userEmail = emailInput.value; // Get the entered email

    // Fetch the user's data and bookings based on the provided email
    fetch(`/getUserData?email=${userEmail}`)
      .then((response) => response.json())
      .then((data) => {
        // Populate the username and bookings based on the data retrieved
        usernamePlaceholder.textContent = data.username;
        populateBookingsTable(data.bookings);
      })
      .catch((error) => {
        console.error('Error fetching user data:', error);
      });
  });

  // Function to populate the bookings table
  function populateBookingsTable(bookings) {
    // Clear the existing table
    table.innerHTML = '<tr><th>Room Number</th><th>Check-In Date</th><th>Check-Out Date</th></tr>';

    if (bookings.length === 0) {
      // Display a message when there are no bookings
      table.innerHTML += '<tr><td colspan="3">No bookings found.</td></tr>';
    } else {
      bookings.forEach((booking) => {
        const row = table.insertRow(-1);
        const roomNumberCell = row.insertCell(0);
        const checkInDateCell = row.insertCell(1);
        const checkOutDateCell = row.insertCell(2);
        roomNumberCell.textContent = booking.roomNumber;
        checkInDateCell.textContent = new Date(booking.startDate).toDateString();
        checkOutDateCell.textContent = new Date(booking.endDate).toDateString();
      });
    }
  }

  // Attach event listeners to the "Update Login Details" and "Delete Account" buttons
  updateDetailsButton.addEventListener('click', () => {
    // Add code to handle updating login details
  });

  deleteAccountButton.addEventListener('click', () => {
    // Add code to handle deleting the user's account
  });
});
