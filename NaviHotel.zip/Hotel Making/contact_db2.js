const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  mobileNumber: String,
  subject: String,
});

// Create a model for the "Contact" collection
const Contact = mongoose.model('Contact', contactSchema);

module.exports = Contact; // Export the model for use in other parts of your app
