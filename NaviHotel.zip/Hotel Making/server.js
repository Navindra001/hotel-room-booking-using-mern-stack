const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const session = require('express-session');
const { MongoClient } = require('mongodb'); // Import MongoClient

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// MongoDB connection setup
const dbURI = 'mongodb://localhost:27017/yourDB-name';
mongoose.connect(dbURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('connected', () => {
  console.log(`Connected to MongoDB at ${dbURI}`);
});

db.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});


// Define Mongoose models
const contactSchema = new mongoose.Schema({
  fullName: String,
  email: String,
  mobileNumber: String,
  subject: String,
});

const Contact = mongoose.model('Contact', contactSchema);

const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  gender: String,
  mobile: String,
});

const User = mongoose.model('User', userSchema);

const bookedRoomSchema = new mongoose.Schema({
  roomNumber: String,
  startDate: Date,
  endDate: Date,
  numPersons: Number,
  email: String,
});

const BookedRoom = mongoose.model('BookedRoom', bookedRoomSchema);

// Configure express-session
app.use(
  session({
    secret: 'your-secret-key', // Change this to a secret key
    resave: false,
    saveUninitialized: true,
  })
);

// Serve the contact page
app.get('/contact', (req, res) => {
  res.sendFile(__dirname + '/contact.html');
});

// Handle form submissions for contact
app.post('/contact', async (req, res) => {
  try {
    // Extract form data from the request body
    const { userName, userEmail, userPhone, userMsg } = req.body;
    const newContact = new Contact({
      fullName: userName,
      email: userEmail,
      mobileNumber: userPhone,
      subject: userMsg,
    });

    await newContact.save();
    res.status(201).send('Data saved to MongoDB');
  } catch (err) {
    console.error('Error saving contact to MongoDB:', err);
    res.status(500).send('Internal Server Error');
  }
});

// Serve the login page
app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/login.html');
});

// Handle user registration
app.post('/signup', async (req, res) => {
  try {
    const { username, email, password, gender, mobile } = req.body;

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(404).send('User Already Exists');
    } else {
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = new User({ username, email, password: hashedPassword, gender, mobile });

      await newUser.save();
      return res.redirect('/indexx.html');

    }
  } catch (err) {
    console.error('Error saving signup to MongoDB:', err);
    return res.status(500).json({ error: err.message });
  }
});

// Handle user login
app.post('/login', async (req, res) => {
  const { username } = req.body;

  try {
    const user = await User.findOne({ username });

    if (user) {
      res.redirect('/indexx.html');
    } else {
     
res.status(404).send('Invalid Username or Password');
    }
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/book-room', async (req, res) => {
  try {
    const { roomNo, startDate, endDate, numPersons, userEmail, totalcost } = req.body;

    // Check room availability for the selected dates
    const roomBookings = await BookedRoom.find({
      roomNumber: roomNo,
      startDate: { $lte: new Date(endDate) },
      endDate: { $gte: new Date(startDate) },
    });

    if (roomBookings.length > 0) {
      // The room is already booked for these dates
     res.status(400).send(`Room not available for the selected dates on please change the Room Number or Date`);
    } else {
      // Calculate the total cost based on your pricing logic
      const costPerPersonPerDay = 200; // Example cost
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      const days = (endDateObj - startDateObj) / (1000 * 60 * 60 * 24);
      const totalCost = costPerPersonPerDay * numPersons * days;

      // Create a new BookedRoom document with the total cost
      const newBookedRoom = new BookedRoom({
        roomNumber: roomNo,
        startDate: startDateObj,
        endDate: endDateObj,
        numPersons: parseInt(numPersons),
        email: userEmail,
        totalCost: totalCost,
      });

      // Save the new BookedRoom document to the database
      await newBookedRoom.save();

      // Respond with a success message
      
res.status(201).send('Room Booked Successfully');

    }
  } catch (err) {
    // Handle errors, e.g., validation errors or database connection issues
    console.error('Error booking room:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/getDetailsByEmail', async (req, res) => {
  const userEmail = req.query.email; // Assuming the email is provided as a query parameter

  try {
    // Fetch the user details based on the provided email
    const userDetails = await User.findOne({ email: userEmail });

    if (!userDetails) {
      return res.status(404).send('No user found for the provided email.');
    }

    // Fetch the room booking data based on the user's email
    const roomBookings = await BookedRoom.find({ email: userEmail });

    const data = {
      user: userDetails,
      bookings: roomBookings,
    };

    res.status(200).json(data);
  } catch (error) {
    console.error('Error fetching details:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/deleteAccount', async (req, res) => {
  const email = req.query.email;

  // Add logic to find and delete the user's account based on the provided email
  try {
    // Find the user by email and delete their account
    await User.deleteOne({ email });

    res.status(200).send('Account deleted successfully');
  } catch (error) {
    console.error('Error deleting account:', error);
    res.status(500).send('An error occurred while deleting the account');
  }
});

// Handle account update
app.post('/updateAccount', async (req, res) => {
  const { currentEmail, newUsername, newPassword } = req.body;

  try {
    // Find the user by the current email
    const user = await User.findOne({ email: currentEmail });

    if (user) {
      // Update the user's details
      user.username = newUsername;
      user.password = newPassword;
      await user.save();

      res.status(200).send('Account updated successfully');
    } else {
      res.status(400).send('User not found');
    }
  } catch (error) {
    console.error('Error updating account:', error);
    res.status(500).send('An error occurred while updating the account.');
  }
});

// Handle room cancellation
// Handle room cancellation
app.post('/cancelRoomBooking', async (req, res) => {
  const email = req.query.email;

  try {
    // Find and remove the room bookings based on the email
    await BookedRoom.deleteMany({ email });

    res.status(200).send('Room cancelled successfully');
  } catch (error) {
    console.error('Error cancelling:', error);
    res.status(500).send('An error occurred while cancelling the room');
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

app.post('/submit-feedback', async (req, res) => {
    console.log('Received feedback submission request'); // Add this line

    const client = new MongoClient(dbURI, { useNewUrlParser: true });

    try {
        await client.connect();
        const db = client.db('yourDB-name');
        const collection = db.collection('feedback');

        const { name, email, subject, message } = req.body;

        const feedbackData = {
            name,
            email,
            subject,
            message,
            timestamp: new Date()
        };

        const result = await collection.insertOne(feedbackData);
        console.log(`Feedback submitted with ID: ${result.insertedId}`);

        res.status(201).send('Feedback submitted successfully');
    } catch (error) {
        console.error('Error submitting feedback:', error);
        res.status(500).send('Error submitting feedback');
    } finally {
        await client.close();
    }
});
