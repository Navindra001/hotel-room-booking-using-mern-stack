const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Connect to your MongoDB database
mongoose.connect('mongodb://localhost:27017/yourDB-name', { useNewUrlParser: true });
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Create a Mongoose schema for room bookings
const bookingSchema = new mongoose.Schema({
  roomNo: String,
  startDate: Date,
  endDate: Date,
  numPersons: Number,
  totalCost: Number,
});

// Create a Mongoose model based on the schema
const Booking = mongoose.model('Booking', bookingSchema);

// Middleware for parsing JSON data
app.use(bodyParser.json());

// Endpoint for handling room booking
app.post('/book-room', (req, res) => {
  const bookingData = req.body;
  const booking = new Booking(bookingData);

  booking.save((err, savedBooking) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error saving booking');
    } else {
      res.status(201).send('Booking saved');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
