const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, JavaScript)
app.use(express.static(path.join(__dirname, 'public')));

// Handle form submissions
app.post('/submit-booking', (req, res) => {
    // Process the form data here (e.g., store it in a database)
    console.log('Received a booking submission:', req.body);
    res.send('Booking submitted successfully.');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
