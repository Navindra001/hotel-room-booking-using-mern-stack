const mongoose = require('mongoose');

// Replace 'your-database-name' with the name of your MongoDB database.
const dbURI = 'mongodb://localhost:27017/yourDB-name';

// Connect to MongoDB
mongoose.connect(dbURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Get the default connection
const db = mongoose.connection;

// Event listeners for the database connection
db.on('connected', () => {
  console.log(`Connected to MongoDB at ${dbURI}`);
});

db.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});

db.on('disconnected', () => {
  console.log('MongoDB disconnected');
});

process.on('SIGINT', () => {
  db.close(() => {
    console.log('MongoDB connection closed due to app termination');
    process.exit(0);
  });
});
