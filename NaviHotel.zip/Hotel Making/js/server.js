const express = require('express');
const app = express();
const port = process.env.PORT || 3000; // Use the provided PORT environment variable or port 3000

// Serve static files (HTML, CSS, images, etc.)
app.use(express.static('public')); // Assuming your HTML and assets are in a 'public' folder

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html'); // Serve the main index.html file
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
