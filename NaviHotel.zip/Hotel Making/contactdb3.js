const Contact = require('./contactModel'); // Import your Contact model

// Inside a route handler
app.post('/contact', (req, res) => {
  const newContact = new Contact({
    fullName: req.body.userName,
    email: req.body.userEmail,
    mobileNumber: req.body.userPhone,
    subject: req.body.userMsg,
  });

  newContact.save((err) => {
    if (err) {
      console.error('Error saving to MongoDB:', err);
      res.status(500).send('Internal Server Error');
    } else {
      res.status(201).send('Data saved to MongoDB');
    }
  });
});
